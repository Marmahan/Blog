/*
    Has no functionality in the Blog
    it helps to add a new document to the Relation collection 
    in the Trust DB
*/

 const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const Relation = require('./Relation');


//creating the server
const app = express();

mongoose.connect('mongodb://localhost/trust',{ useNewUrlParser: true });
mongoose.Promise = global.Promise;

//so the app can handle json requests
app.use(bodyParser.json());


//old way with no services from outside
//post request to save a new user
app.post('/newrelation', function(req,res){

    var newRelation ={
        name: req.body.name,
        port: req.body.port,
        sid: req.body.sid,
        services: req.body.services
    }
    var relation = new Relation (newRelation);
    relation.save().then(function(){
        res.send('1');
    }).catch(function(err){
        if(err)
            throw err;
    });  

});


//Service is listening to port 1501
app.listen(1501, function(){
    console.log("Service: (Add Relation, listening to 1501) is running...");
});
