/*
    Comments microservice
    save a comment, get all comments of a specific post
    has its own DB
*/ 

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Comment = require('./Comment');
const axios = require('axios');
var cors = require('cors');         //to handle cors error !!! required in all services
var async = require("async");


//creating the server
const app = express();
app.use(cors());

//connect to mongodb
mongoose.connect('mongodb://localhost/comments',{ useNewUrlParser: true });
mongoose.Promise = global.Promise;

//so the app can handle json requests
app.use(bodyParser.json());


//post request to save a new comment
app.post('/newcomment', function(req,res){
    var duplicationport=0;
    var validationport=0;
    var start = Date.now();
    axios.post('http://localhost:2000/evaluate', { //trust evaluation for validation
    serviceName:"validation",//send the name of the requesting service
    reqPort: "1116" //send the number of the requesting service
    }).then(response => {
        validationport=response.data;
        var duration = Date.now() - start;
        console.log("Time:"+duration/1000);
        res.send(validationport.toString());
        console.log(validationport);
    });

});
               

//get all comments of a specific post
app.get('/comments/:id', function(req,res){
    //req.user.userID is brought from the token
    Comment.find({postID: req.params.id}, function(err, comments){
        if(err)
            res.status(402).send('No Comments yet');
        else
            res.json(comments);
    });
});




//Service is listening to port 1116
app.listen(1116, function(){
    console.log("Service: (Comments) is running...");
});




/*

{
    "postID": "5c77b37d6fb0e10664c8ed8e",
    "email": "testemail@test.com",
    "commentbody": "This is the first comment"
}

*/