/*
    Service model
*/

const mongoose = require('mongoose');


const Service = mongoose.model('Service',{
   name :{
       type: String,
       required: true
   },
   port :{
    type: Number,
    required: true
    },
   source :{
        type: String,
        required: true
    }, 
    devtrust :{
        type: Number,
        required: true
    },
    sensitivity :{
        type: String,
        required: true
    },
    startdate: {
        type: Date,
        required: true
    },
    lastsuccess: {
        type: Date,
        required: true
    },
    interactions: { //accepted & rejected
        type: Number,
        required: true
    },
    successful: { //accepted 
        type: Number,
        required: true
    },
    failed: { // rejected
        type: Number,
        required: true
    }

});

module.exports = Service;



