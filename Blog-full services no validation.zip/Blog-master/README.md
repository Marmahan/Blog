# Blog
Blog based on Microservice architecture. The Blog has, as its backend, many services interacting with each other.
